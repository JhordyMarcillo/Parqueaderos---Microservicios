package ec.edu.espe.zone_core.model;

public enum SpaceStatus {
    AVAILABLE,
    OCCUPIED,
    MAINTENANCE
}

