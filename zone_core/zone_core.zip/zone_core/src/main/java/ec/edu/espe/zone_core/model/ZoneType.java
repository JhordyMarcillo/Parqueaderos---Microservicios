package ec.edu.espe.zone_core.model;

public enum ZoneType {
    VIP, INTERNAL, EXTERNAL
}

